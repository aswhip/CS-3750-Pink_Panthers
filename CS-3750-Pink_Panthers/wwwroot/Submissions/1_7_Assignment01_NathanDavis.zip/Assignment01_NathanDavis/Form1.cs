namespace Assignment01_NathanDavis
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// These functions determine what each button press does
        /// </summary>
   
        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult MyResult; //This variable tells us what button was pressed at the end.

            //This stores the button press into the MyResult Variable, and shows the entered text
            MyResult = MessageBox.Show("Message Entered: " + textBox1.Text, "Entered Message", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);

            //This updates the label showing what button was pressed
            label5.Text = "You clicked the " + MyResult.ToString() + " button";

        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult MyResult; //This variable tells us what button was pressed at the end.

            if (textBox2.Text == "Warning") //For the Warning MessageBox Option
                MyResult = MessageBox.Show("MessageBox Shown: " + textBox2.Text, "Message Box", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);

            else if (textBox2.Text == "Asterisk") //For the Asterisk MessageBox Option
                MyResult = MessageBox.Show("MessageBox Shown: " + textBox2.Text, "Message Box", MessageBoxButtons.OKCancel, MessageBoxIcon.Asterisk);

            else if (textBox2.Text == "Exclamation") //For the Exclamation MessageBox Option
                MyResult = MessageBox.Show("MessageBox Shown: " + textBox2.Text, "Message Box", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);

            else if (textBox2.Text == "Information") //For the Information MessageBox Option
                MyResult = MessageBox.Show("MessageBox Shown: " + textBox2.Text, "Message Box", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);

            else //If none of the above options are entered, show the error messagebox
                MyResult = MessageBox.Show("MessageBox Shown: Error. Reason: Unknown Command", "Message Box", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);

            label6.Text = "You clicked the " + MyResult.ToString() + " button"; //Shows what button was pressed


        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult MyResult; //This variable tells us what button was pressed at the end.

            //This stores the button press into the MyResult Variable
            MyResult = MessageBox.Show("Message Entered: " + textBox3.Text + ". Is this correct?", "Button Press", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

            //This updates the label showing what button was pressed
            label3.Text = "You clicked the " + MyResult.ToString() + " button";
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}