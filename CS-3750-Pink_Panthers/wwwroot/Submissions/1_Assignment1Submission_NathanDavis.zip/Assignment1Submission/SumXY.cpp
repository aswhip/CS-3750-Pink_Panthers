//                      Nathan Davis
//                      CS 4110 - 9:30 am
//                      Assignment #1
//                      Dr. Rague
//                      Due: 09/16/23
//                      Version: 1.0
// -----------------------------------------------------------------
// This program takes in one number and calculates if there are any
// combination of 17 and 43 that can be added to make that number
// -----------------------------------------------------------------



// Compiler directives
#include <iostream>
#include <string>
#include <sstream>

bool SumXY(int num) {
	if (num == 17 || num == 43) //Base cases
		return true;
	
	if (num < 17) //If number is less than 17 then its not included
		return false;
	
	return(SumXY(num - 43) || SumXY(num - 17)); //Checks for num-43 and num-17. If either path returns true, then the whole path returns true
}

int main(int argc, char** argv) {
	if (argc >= 2) {
		for (int i = 1; i < argc; ++i) { //To allow for multiple test cases to be entered on the commandline
			std::stringstream iss(argv[i]);
			int num;
			if (iss >> num) { //Tries to insert the stringstream into an int value. If it can't, then its not an integer and return an error message.
				bool isInLanguage = SumXY(num);
				std::string member = isInLanguage ? "true" : "false"; //C++ prints bools as 0s and 1s, so this is one way to convert it to true/false.
				std::cout << "X = " << num << " Member? " << member << std::endl;
			}
			else { //Just for ease of readability
				if(i == 1)
					std::cout << i << "st value is an invalid value." << std::endl;
				else if (i == 2)
					std::cout << i << "nd value is an invalid value." << std::endl;
				else if (i == 3)
					std::cout << i << "rd value is an invalid value." << std::endl;
				else
					std::cout << i << "th value is an invalid value." << std::endl;
			}
		}
	}
	else { //Tells the user that a value must be entered on the commandline
		std::cout << "Enter number on command line." << std::endl;
	}

	return 0;
}