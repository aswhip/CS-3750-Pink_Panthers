//                      Nathan Davis
//                      CS 4110 - 9:30 am
//                      Assignment #1
//                      Dr. Rague
//                      Due: 09/16/23
//                      Version: 1.0
// -----------------------------------------------------------------
// This program takes in a word consisting of a's and b's. If the
// word is a palindrome of an odd number of a's and b's, returns true
// -----------------------------------------------------------------



// Compiler directives
#include <iostream>
#include <string>
#include <sstream>
#include <set> //Using sets for the allowed alphabet

std::set<char> alphabet = { 'a', 'b' }; //Allowed alphabet
bool OddPalindrome(const std::string &word) {
	if (word == "a" || word == "b") //Base cases
		return true;

	if (word.length() <= 0) //If the passed in substring is 0 characters long, return false
		return false;

	for (char c : word) { //If the word contains any letters not in the alphabet, return false
		if (alphabet.find(c) == alphabet.end())
			return false;
	}

	if (word.front() == word.back()) { //If the first and last letters are the same
		std::string sub = word.substr(1, word.length() - 2); //index is from 0 -> length() - 1. To cut off the first and last letters we move from index 1 -> length() - 2
		return OddPalindrome(sub);
	}
	else {
		return false;
	}
}

int main(int argc, char** argv) {
	if (argc >= 2) {
		for (int i = 1; i < argc; i++) {
			std::string word = (argv[i]);
			bool isInLanguage = OddPalindrome(word);
			std::string member = isInLanguage ? "true" : "false";
			std::cout << "Word = " << word << " Member? " << member << std::endl;
		}
	}
	else {
		std::cout << "Enter word(s) on the command line." << std::endl;
	}

	return 0;
}