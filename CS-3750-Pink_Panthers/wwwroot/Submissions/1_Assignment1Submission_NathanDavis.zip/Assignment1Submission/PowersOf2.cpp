//                      Nathan Davis
//                      CS 4110 - 9:30 am
//                      Assignment #1
//                      Dr. Rague
//                      Due: 09/16/23
//                      Version: 1.0
// -----------------------------------------------------------------
// This program determines if the passed in value is a power of 2
// or if num = 2^x
// -----------------------------------------------------------------



// Compiler directives
#include <iostream>
#include <string>
#include <sstream>

bool PowersOf2(double num) {
	if (num == 1) //Base case
		return true;
	if (num < 1) //If we get a decimal, return false
		return false;

	return PowersOf2(num / 2); //Recursively divides num by 2
}

int main(int argc, char** argv) {
	if (argc >= 2) {
		for (int i = 1; i < argc; ++i) { //To allow for multiple test cases to be entered on the commandline
			std::stringstream iss(argv[i]);
			int num;
			if (iss >> num) { //Tries to insert the stringstream into an int value. If it can't, then its not an integer and return an error message.
				bool isInLanguage = PowersOf2(num);
				std::string member = isInLanguage ? "true" : "false"; //C++ prints bools as 0s and 1s, so this is one way to convert it to true/false.
				std::cout << "X = " << num << " Member? " << member << std::endl;
			}
			else { //Just for ease of readability
				if (i == 1)
					std::cout << i << "st value is an invalid value." << std::endl;
				else if (i == 2)
					std::cout << i << "nd value is an invalid value." << std::endl;
				else if (i == 3)
					std::cout << i << "rd value is an invalid value." << std::endl;
				else
					std::cout << i << "th value is an invalid value." << std::endl;
			}
		}
	}
	else { //Tells the user that a value must be entered on the commandline
		std::cout << "Enter number on command line." << std::endl;
	}

	return 0;
}