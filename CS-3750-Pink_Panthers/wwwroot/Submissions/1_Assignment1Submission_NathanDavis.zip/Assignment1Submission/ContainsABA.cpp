//                      Nathan Davis
//                      CS 4110 - 9:30 am
//                      Assignment #1
//                      Dr. Rague
//                      Due: 09/16/23
//                      Version: 1.0
// -----------------------------------------------------------------
// This program checks a string to see if it contains the sequence
// 'aba' anywhere in the string. Only consists of a's anb b's
// -----------------------------------------------------------------



// Compiler directives
#include <iostream>
#include <string>
#include <set>

std::set<char> alphabet = { 'a', 'b' }; //Alphabet for ContainsABA
bool ContainsABA(const std::string &word) {

	if (word.length() < 3) //If the substring is less than 3 characters, it cannot contain aba
		return false;
	
	for (char c : word) { //Checks each letter in the word. If any letter is not in the alphabet, return false
		if (alphabet.find(c) == alphabet.end())
			return false;
	}

	std::string sub = word.substr(0, 3);

	if (sub == "aba") //If the current substring is aba, then the word contains aba so we return true
		return true;

	std::string next = word.substr(1, word.length()); //If the current substring is not aba, cut off the first letter and pass in the new string
	return ContainsABA(next); 
}

int main(int argc, char** argv) {
	if (argc >= 2) {
		for (int i = 1; i < argc; i++) {
			std::string word = (argv[i]);
			bool isInLanguage = ContainsABA(word);
			std::string member = isInLanguage ? "true" : "false";
			std::cout << "Word = " << word << " Member? " << member << std::endl;
		}
	}
	else {
		std::cout << "Enter word(s) on the command line." << std::endl;
	}

	return 0;
}