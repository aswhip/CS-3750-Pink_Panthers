//                      Nathan Davis
//                      CS 4110 - 9:30 am
//                      Assignment #1
//                      Dr. Rague
//                      Due: 09/16/23
//                      Version: 1.0
// -----------------------------------------------------------------
// This program takes in a number and determines if it is a 
// multiple of 7
// -----------------------------------------------------------------



// Compiler directives
#include <iostream>
#include <string>
#include <sstream>

bool DivisibleBy7(int num) { //For test case 52878, I don't think functions are meant to be called 7500 times. It causes a stack overflow.
	if (num == 0 || num == 7) //Base case
		return true;
	if (num < 0) //If we go negative, return false
		return false;

	return DivisibleBy7(num - 7); //Work our way down to 0 or 7.
}

int main(int argc, char** argv) {
	if (argc >= 2) {
		for (int i = 1; i < argc; ++i) { //To allow for multiple test cases to be entered on the commandline
			std::stringstream iss(argv[i]);
			int num;
			if (iss >> num) { //Tries to insert the stringstream into an int value. If it can't, then its not an integer and return an error message.
				bool isInLanguage = DivisibleBy7(num);
				std::string member = isInLanguage ? "true" : "false"; //C++ prints bools as 0s and 1s, so this is one way to convert it to true/false.
				std::cout << "X = " << num << " Member? " << member << std::endl;
			}
			else { //Just for ease of readability
				if (i == 1)
					std::cout << i << "st value is an invalid value." << std::endl;
				else if (i == 2)
					std::cout << i << "nd value is an invalid value." << std::endl;
				else if (i == 3)
					std::cout << i << "rd value is an invalid value." << std::endl;
				else
					std::cout << i << "th value is an invalid value." << std::endl;
			}
		}
	}
	else { //Tells the user that a value must be entered on the commandline
		std::cout << "Enter number on command line." << std::endl;
	}

	return 0;
}