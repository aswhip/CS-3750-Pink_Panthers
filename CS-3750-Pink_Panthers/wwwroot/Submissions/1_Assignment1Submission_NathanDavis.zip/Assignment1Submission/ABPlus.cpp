//                      Nathan Davis
//                      CS 4110 - 9:30 am
//                      Assignment #1
//                      Dr. Rague
//                      Due: 09/16/23
//                      Version: 1.0
// -----------------------------------------------------------------
// This program checks for a concatenation of a's, b's, and +'s.
// a and b are words, for v and b in language, vb and v+b are words.
// -----------------------------------------------------------------



// Compiler directives
#include <iostream>
#include <string>
#include <set>

std::set<char> alphabet = { 'a', 'b', '+' }; //Alphabet
bool ABPlus(const std::string &word) {
	if (word == "a" || word == "b") //Base cases
		return true;
	if (word == "a+a" || word == "a+b" || word == "b+a" || word == "b+b") //Base + concatenation
		return true;
	if (word.length() <= 0) //If the word is just a null space, return false
		return false;
	for (char c : word) { //If the word contains letters outside the alphabet, return false
		if (alphabet.find(c) == alphabet.end())
			return false;
	}

	for (int i = 1; i < word.length(); ++i) { //Start at the first letter and separate the strings, then check if both substrings are in ABPlus
		std::string v = word.substr(0, i);    //If both strings are in ABPlus, the word is in ABPlus. If they aren't, keep separating them until
		std::string w = word.substr(i);		  //All possible substrings have been tested. If no substring combination is in ABPlus, then the word is not in ABPlus
		if (ABPlus(v) && ABPlus(w))		      //And return false.
			return true;
	}
	return false; //Default case
}

int main(int argc, char** argv) {
	if (argc >= 2) {
		for (int i = 1; i < argc; i++) {
			std::string word = (argv[i]);
			bool isInLanguage = ABPlus(word);
			std::string member = isInLanguage ? "true" : "false";
			std::cout << "Word = " << word << " Member? " << member << std::endl;
		}
	}
	else {
		std::cout << "Enter word(s) on the command line." << std::endl;
	}

	return 0;
}