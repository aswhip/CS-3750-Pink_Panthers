﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment04_NathanDavis
{
    /// <summary>
    /// AITicTacToe is derived from the TicTacToe class, sharing it's public attributes.
    /// </summary>
    public class AITicTacToe : TicTacToe
    {
        private string[,] copyBoard = new string[3, 3];
        private int tRow, tCol;
        Random rand = new Random(); //Used for when there is no move the AI can make to win or block a winning move
        private int row1C, row2C, row3C, col1C, col2C, col3C, diag1C, diag2C;

        /// <summary>
        /// Default constructor to initialize the copyBoard, which this class has access to
        /// </summary>
        public AITicTacToe()
        {
            for(int row = 0; row < 3; row++)
            {
                for(int col = 0; col < 3; col++)
                {
                    setPos(row, col);
                    copyBoard[row, col] = GameBoard;
                }
            }
        }

        /// <summary>
        /// Copies the gameBoard array to the copyBoard array
        /// </summary>
        public void copy()
        {
            for (int row = 0; row < 3; row++)
            {
                for (int col = 0; col < 3; col++)
                {
                    setPos(row, col);
                    copyBoard[row, col] = GameBoard;
                }
            }
        }

        /// <summary>
        /// Calculates if there are any moves that will allow the AI to win or block the human from winning. 
        /// If not, just makes a random move
        /// </summary>
        /// <returns></returns>
        public bool getMove()
        {
            copy();
            if (hasWinningMove()) //If there is a winning move, make it
            {
                makeMove(tRow, tCol);
                return true;
            }
            else if (blockWinningMove()) //If there is not a winning move, and there is a move to block the human from winning, make it
            {
                makeMove(tRow, tCol);
                return true;
            }
            else //If no winning or win blocking move, make a random move
            {
                tRow = rand.Next(3);
                tCol = rand.Next(3);
                if (isEmpty(tRow, tCol)) //Makes sure the space we are making a move on is empty so we don't override the board
                {
                    makeMove(tRow, tCol);
                    return true;
                }
                else
                    getMove();
            }
            return false;
        }

        /// <summary>
        /// Sets the position for the AI to make a move, and sets the gameBoard of that row and col to the correct letter
        /// </summary>
        /// <param name="row"></param>
        /// <param name="col"></param>
        private void makeMove(int row, int col)
        {
            setPos(row, col);
            copyBoard[row, col] = "O";
            GameBoard = copyBoard[row, col];
        }

        /// <summary>
        /// Goes through each row, column, and diagonal to see if there are any moves the human can make to win. Blocks it if there are
        /// </summary>
        /// <returns></returns>
        public bool blockWinningMove()
        {
            row1C = row2C = row3C = 0;
            col1C = col2C = col3C = 0;
            diag1C = diag2C = 0;

            for (int row = 0; row < 3; row++) //Going through each row first
            {
                for(int col = 0; col < 3; col++)
                {
                    if (row == 0 && copyBoard[row, col].Equals("X"))
                        row1C++;
                    else if (row == 1 && copyBoard[row, col].Equals("X"))
                        row2C++;
                    else if (row == 2 && copyBoard[row, col].Equals("X"))
                        row3C++;
                }
            }
            for(int col = 0; col < 3; col++) //Going through each column
            {
                for(int row = 0; row < 3; row++)
                {
                    if (col == 0 && copyBoard[row, col].Equals("X"))
                        col1C++;
                    else if (col == 1 && copyBoard[row, col].Equals("X"))
                        col2C++;
                    else if (col == 2 && copyBoard[row, col].Equals("X"))
                        col3C++;
                }
            }
            for(int d = 0; d < 3; d++) //Checking forward diagonal
            {
                if (copyBoard[d, d].Equals("X"))
                    diag1C++;
            }
            for(int row = 0; row < 3; row++) //Checking reverse diagonal
            {
                for(int col = 2; col >= 0; col--)
                {
                    if (row + col - 1 == 1 && copyBoard[row, col].Equals("X"))
                        diag2C++;
                }
            }
            //Checking each row, column, and diagonal 'X' count. If there is one with 2 X's, block that move.
            if(row1C == 2)
            {
                for(int col = 0; col < 3; col++)
                {
                    if(isEmpty(0, col))
                    {
                        tRow = 0;
                        tCol = col;
                        return true;
                    }
                }
            }
            if (row2C == 2)
            {
                for (int col = 0; col < 3; col++)
                {
                    if (isEmpty(1, col))
                    {
                        tRow = 1;
                        tCol = col;
                        return true;
                    }
                }
            }
            if (row3C == 2)
            {
                for (int col = 0; col < 3; col++)
                {
                    if (isEmpty(2, col))
                    {
                        tRow = 2;
                        tCol = col;
                        return true;
                    }
                }
            }
            if (col1C == 2)
            {
                for (int row = 0; row < 3; row++)
                {
                    if (isEmpty(row, 0))
                    {
                        tRow = row;
                        tCol = 0;
                        return true;
                    }
                }
            }
            if (col2C == 2)
            {
                for (int row = 0; row < 3; row++)
                {
                    if (isEmpty(row, 1))
                    {
                        tRow = row;
                        tCol = 1;
                        return true;
                    }
                }
            }
            if (col3C == 2)
            {
                for (int row = 0; row < 3; row++)
                {
                    if (isEmpty(row, 2))
                    {
                        tRow = row;
                        tCol = 2;
                        return true;
                    }
                }
            }
            if (diag1C == 2)
            {
                for (int d = 0; d < 3; d++)
                {
                    if (isEmpty(d, d))
                    {
                        tRow = d;
                        tCol = d;
                        return true;
                    }
                }
            }
            if (diag2C == 2)
            {
                for (int row = 0; row < 3; row++)
                {
                    for (int col = 2; col >= 0; col--)
                    {
                        if (row + col - 1 == 1 && isEmpty(row, col))
                        {
                            tRow = row;
                            tCol = col;
                            return true;
                        }
                    }
                }
            }

            return false; //Returns false if there are no moves to block a winning move.
        }
        /// <summary>
        /// Checks each row, col, and diagonal to see if the AI can make a winning move. Makes it if it can
        /// </summary>
        /// <returns></returns>
        public bool hasWinningMove()
        {
            row1C = row2C = row3C = 0;
            col1C = col2C = col3C = 0;
            diag1C = diag2C = 0;

            for (int row = 0; row < 3; row++) //Going through the rows first
            {
                for (int col = 0; col < 3; col++)
                {
                    if (row == 0 && copyBoard[row, col].Equals("O"))
                        row1C++;
                    else if (row == 1 && copyBoard[row, col].Equals("O"))
                        row2C++;
                    else if (row == 2 && copyBoard[row, col].Equals("O"))
                        row3C++;
                }
            }
            for (int col = 0; col < 3; col++) //Going through the columns next
            {
                for (int row = 0; row < 3; row++)
                {
                    if (col == 0 && copyBoard[row, col].Equals("O"))
                        col1C++;
                    else if (col == 1 && copyBoard[row, col].Equals("O"))
                        col2C++;
                    else if (col == 2 && copyBoard[row, col].Equals("O"))
                        col3C++;
                }
            }
            for (int d = 0; d < 3; d++) //Checking forwards diagonal
            {
                if (copyBoard[d, d].Equals("O"))
                    diag1C++;
            }
            for (int row = 0; row < 3; row++) //Checking reverse diagonal
            {
                for (int col = 2; col >= 0; col--)
                {
                    if (row + col - 1 == 1 && copyBoard[row, col].Equals("O"))
                        diag2C++;
                }
            }

            if (row1C == 2) //Checking each row, col, and diagonal 'O' count.
            {
                for (int col = 0; col < 3; col++)
                {
                    if (isEmpty(0, col))
                    {
                        tRow = 0;
                        tCol = col;
                        return true;
                    }
                }
            }
            if (row2C == 2)
            {
                for (int col = 0; col < 3; col++)
                {
                    if (isEmpty(1, col))
                    {
                        tRow = 1;
                        tCol = col;
                        return true;
                    }
                }
            }
            if (row3C == 2)
            {
                for (int col = 0; col < 3; col++)
                {
                    if (isEmpty(2, col))
                    {
                        tRow = 2;
                        tCol = col;
                        return true;
                    }
                }
            }
            if (col1C == 2)
            {
                for (int row = 0; row < 3; row++)
                {
                    if (isEmpty(row, 0))
                    {
                        tRow = row;
                        tCol = 0;
                        return true;
                    }
                }
            }
            if (col2C == 2)
            {
                for (int row = 0; row < 3; row++)
                {
                    if (isEmpty(row, 1))
                    {
                        tRow = row;
                        tCol = 1;
                        return true;
                    }
                }
            }
            if (col3C == 2)
            {
                for (int row = 0; row < 3; row++)
                {
                    if (isEmpty(row, 2))
                    {
                        tRow = row;
                        tCol = 2;
                        return true;
                    }
                }
            }
            if (diag1C == 2)
            {
                for (int d = 0; d < 3; d++)
                {
                    if (isEmpty(d, d))
                    {
                        tRow = d;
                        tCol = d;
                        return true;
                    }
                }
            }
            if (diag2C == 2)
            {
                for (int row = 0; row < 3; row++)
                {
                    for (int col = 2; col >= 0; col--)
                    {
                        if (row + col - 1 == 1 && isEmpty(row, col))
                        {
                            tRow = row;
                            tCol = col;
                            return true;
                        }
                    }
                }
            }

            return false; //If there is no winning move, return false
        }
    }
}
