﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment04_NathanDavis
{
    /// <summary>
    /// This is the game engine for the TicTacToe game, running behind the UI. All the game rules run through here, while
    /// MainWindow.xaml.cs just handles displaying it to the user.
    /// </summary>
    public class TicTacToe
    {
        private string[,] gameBoard; //Array for the game board
        private int iPlayer1Wins = 0;
        private int iPlayer2Wins = 0;
        private int iTies = 0;
        private WinningMove winningMove;
        public Status status;
        private bool win, tie;
        private int row, col;
        public bool row1, row2, row3, col1, col2, col3, diag1, diag2;

        /// <summary>
        /// An enumeration used to determine what the winning move is
        /// </summary>
        private enum WinningMove
        {
            Row1,
            Row2,
            Row3,
            Col1,
            Col2,
            Col3,
            Diag1,
            Diag2,
            None
        }

        /// <summary>
        /// An enumeration used to determine the current status of the game
        /// </summary>
        public enum Status
        {
            Player1Turn,
            Player2Turn,
            Player1Win,
            Player2Win,
            Tie
        }

        /// <summary>
        /// Default constructor to initialize the game
        /// </summary>
        public TicTacToe()
        {
            gameBoard = new string[3, 3];
            for(int row = 0; row < 3; row++)
            {
                for(int col = 0; col < 3; col++)
                {
                    gameBoard[row, col] = "";
                }
            }
            iPlayer1Wins = 0;
            iPlayer2Wins = 0;
            iTies = 0;
            winningMove = WinningMove.None;
        }

        /// <summary>
        /// A property to handle the gameBoard array, setting the position of gameBoard[row,col] to X/O, or returning the value of gameBoard[row,col]
        /// </summary>
        public string GameBoard
        {
            get { return gameBoard[row, col]; }
            
            set { gameBoard[row, col] = value; }
        }

        /// <summary>
        /// Used to determine if the position in the array needs to be an X or O.
        /// </summary>
        /// <returns></returns>
        public string getTurn()
        {
            if (status == Status.Player1Turn)
                return "X";
            else if (status == Status.Player2Turn)
                return "O";
            return "";
        }

        /// <summary>
        /// Could use two properties to handle this, but having one method to do both at the same time is more effecient
        /// </summary>
        /// <param name="r"></param>
        /// <param name="c"></param>
        public void setPos(int r, int c)
        {
            row = r;
            col = c;
        }

        /// <summary>
        /// Checks if the position on the board is empty. Returns true if empty, false if not
        /// </summary>
        /// <param name="r"></param>
        /// <param name="c"></param>
        /// <returns></returns>
        public bool isEmpty(int r, int c)
        {
            if (gameBoard[r, c].Equals(""))
                return true;
            return false;
        }

        /// <summary>
        /// Sets a boolean value depending on what the winning move was to highlight the proper row/col/diag
        /// </summary>
        public void getWinningMove()
        {
            if(winningMove == WinningMove.Row1)
            {
                row1 = true;
            }
            else if(winningMove == WinningMove.Row2)
            {
                row2 = true;
            }
            else if(winningMove == WinningMove.Row3)
            {
                row3 = true;
            }
            else if (winningMove == WinningMove.Col1)
            {
                col1 = true;
            }
            else if (winningMove == WinningMove.Col2)
            {
                col2 = true;
            }
            else if (winningMove == WinningMove.Col3)
            {
                col3 = true;
            }
            else if (winningMove == WinningMove.Diag1)
            {
                diag1 = true;
            }
            else if (winningMove == WinningMove.Diag2)
            {
                diag2 = true;
            }
        }

        /// <summary>
        /// Determines if there was a winning move that was made, and what that winning move was
        /// </summary>
        /// <returns></returns>
        public bool isWinningMove()
        {
            if (!win)
                win = isHorizontal();
            if (!win)
                win = isVertical();
            if (!win)
                win = isDiag();
            return win;
        }

        /// <summary>
        /// If the winning move was horizontal, was it row 1, 2, or 3
        /// </summary>
        /// <returns></returns>
        private bool isHorizontal()
        {
            //Checking row 1
            if (gameBoard[0, 0].Equals(gameBoard[0,1]) && gameBoard[0, 0].Equals(gameBoard[0, 2]) && (gameBoard[0,0].Equals("X") || gameBoard[0,0].Equals("O")))
            {
                winningMove = WinningMove.Row1;
                return true;
            }
            //Checking row 2
            else if (gameBoard[1, 0].Equals(gameBoard[1, 1]) && gameBoard[1, 0].Equals(gameBoard[1, 2]) && (gameBoard[1, 0].Equals("X") || gameBoard[1, 0].Equals("O")))
            {
                winningMove = WinningMove.Row2;
                return true;
            }
            //Checking row 3
            else if (gameBoard[2, 0].Equals(gameBoard[2, 1]) && gameBoard[2, 0].Equals(gameBoard[2, 2]) && (gameBoard[2, 0].Equals("X") || gameBoard[2, 0].Equals("O")))
            {
                winningMove = WinningMove.Row3;
                return true;
            }
            //If none, return false
            return false;
        }

        /// <summary>
        /// Checks if the winning move was vertical, and what column it was
        /// </summary>
        /// <returns></returns>
        private bool isVertical()
        {
            //Column 1
            if (gameBoard[0, 0].Equals(gameBoard[1,0]) && gameBoard[0, 0].Equals(gameBoard[2, 0]) && (gameBoard[0, 0].Equals("X") || gameBoard[0, 0].Equals("O")))
            {
                winningMove = WinningMove.Col1;
                return true;
            }
            //Column 2
            else if (gameBoard[0, 1].Equals(gameBoard[1, 1]) && gameBoard[0, 1].Equals(gameBoard[2, 1]) && (gameBoard[0, 1].Equals("X") || gameBoard[0, 1].Equals("O")))
            {
                winningMove = WinningMove.Col2;
                return true;
            }
            //Column 3
            else if (gameBoard[0, 2].Equals(gameBoard[1, 2]) && gameBoard[0, 2].Equals(gameBoard[2, 2]) && (gameBoard[0, 2].Equals("X") || gameBoard[0, 2].Equals("O")))
            {
                winningMove = WinningMove.Col3;
                return true;
            }
            //If none
            return false;
        }

        /// <summary>
        /// Checks if the winning move was a diagonal move
        /// </summary>
        /// <returns></returns>
        private bool isDiag()
        {
            //Top left to bottom right
            if (gameBoard[0, 0].Equals(gameBoard[1,1]) && gameBoard[0, 0].Equals(gameBoard[2, 2]) && (gameBoard[0, 0].Equals("X") || gameBoard[0, 0].Equals("O")))
            {
                winningMove = WinningMove.Diag1;
                return true;
            }
            //Bottom left to top right
            else if (gameBoard[0, 2].Equals(gameBoard[1, 1]) && gameBoard[0, 2].Equals(gameBoard[2, 0]) && (gameBoard[0, 2].Equals("X") || gameBoard[0, 2].Equals("O")))
            {
                winningMove = WinningMove.Diag2;
                return true;
            }
            //If none
            return false;
        }

        /// <summary>
        /// Checks if the game ends in a tie. Checks for any open spaces. If no open spaces, and no one has won, its a tie.
        /// </summary>
        /// <returns></returns>
        public bool isTie()
        {
            for (int row = 0; row < 3; row++)
            {
                for (int col = 0; col < 3; col++)
                {
                    if (gameBoard[row, col].Equals("")){ //Going through each position in the array, if there is a single open space, its false
                        tie = false;
                        return tie;
                    }
                }
            }
            tie = true;
            status = Status.Tie;
            iTies++;
            return tie;
        }

        /// <summary>
        /// Updates the status to know what state of the game we are in
        /// </summary>
        /// <returns></returns>
        public string changeStatus()
        {
            string statusUpdate = "";
            if (tie) //If there's a tie, we are in the Tie status
            {
                status = Status.Tie;
                statusUpdate = "It's a Tie!";
            }
            else if (win && status == Status.Player1Turn) //If someone won, and it was Player 1's move that won, player 1 won
            {
                status = Status.Player1Win;
                statusUpdate = "Player 1 Wins!";
                iPlayer1Wins++;
            }
            else if (win && status == Status.Player2Turn) //If someone won, and it was Player 2's move that won, player 2 won
            {
                status = Status.Player2Win;
                statusUpdate = "Player 2 Wins!";
                iPlayer2Wins++;
            }
            else if (status == Status.Player1Turn) //If no one has won, and it was previously player 1's turn, its now player 2's turn
            {
                status = Status.Player2Turn;
                statusUpdate = "Player 2's Turn";
            }
            else if (status == Status.Player2Turn) //If no one has won, and it was previously player 2's turn, its now player 1's turn
            {
                status = Status.Player1Turn;
                statusUpdate = "Player 1's Turn";
            }
            return statusUpdate;
        }

        /// <summary>
        /// Returns how many times player 1 has won
        /// </summary>
        /// <returns></returns>
        public int getPlayer1Wins()
        {
            return iPlayer1Wins;
        }
        /// <summary>
        /// Returns how many times player 2 has won
        /// </summary>
        /// <returns></returns>
        public int getPlayer2Wins()
        {
            return iPlayer2Wins;
        }
        /// <summary>
        /// Returns how many ties there have been
        /// </summary>
        /// <returns></returns>
        public int getTies()
        {
            return iTies;
        }

        /// <summary>
        /// Resets everything except for the stat counts. 
        /// </summary>
        public void reset()
        {
            status = Status.Player1Turn;
            for (int row = 0; row < 3; row++)
            {
                for (int col = 0; col < 3; col++)
                {
                    gameBoard[row, col] = "";
                }
            }
            winningMove = WinningMove.None;
            win = false;
            tie = false;
            row1 = row2 = row3 = col1 = col2 = col3 = diag1 = diag2 = false;
        }

    }

    
}
