﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Assignment04_NathanDavis
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// Declaring variables for use later
        /// </summary>
        TicTacToe game;
        AITicTacToe vsAi;
        bool aiGame = false, humanGame = false;
        bool hasGameStarted;
        bool hasWon, isTie;
        public MainWindow()
        {
            game = new TicTacToe(); //Setting up the game variable
            vsAi = new AITicTacToe(); //Sets up the AI class
            InitializeComponent();
            resetLabels();
            lblStatus.Content = "";
        }

        /// <summary>
        /// Called when the Start Button is clicked. Resets the game, leaving the counts alone
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnStart_Click(object sender, RoutedEventArgs e)
        {
            humanGame = true;
            aiGame = false;
            game.reset();
            hasWon = false;
            hasGameStarted = true;
            resetColors();
            resetLabels();
            lblStatus.Content = "Player 1's Turn";
        }


        /// <summary>
        /// Called when the Start vs AI button is clicked. 
        /// Start starts a human game, Start vs AI starts a game against an AI
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnVsAi_Click(object sender, RoutedEventArgs e)
        {
            aiGame = true;
            humanGame = false;
            vsAi.reset();
            hasWon = false;
            hasGameStarted = true;
            resetColors();
            resetLabels();
            lblStatus.Content = "Player 1's Turn";
        }

        /// <summary>
        /// Called when a square is clicked. Checks for several things.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void playerMoveClick(object sender, MouseButtonEventArgs e)
        {
            //If the game has started, then we can play
            if (hasGameStarted)
            {
                //If we are playing against a human, we go through this list
                if (humanGame) { 
                    string status = "Player 1's Turn"; //Default status
                    Label obj = (Label)sender; //We will want to know what label was clicked on
                    string[]? pos = obj.Tag.ToString().Split(","); //Used to identify position. Each tag has a row/col in the form of r,c
                    int row, col;
                    row = Int32.Parse(pos[0]); //Gets the row position from the Tag
                    col = Int32.Parse(pos[1]); //Gets the col position from the Tag

                    if (game.isEmpty(row, col)) //If the spot on the board is empty, its a valid move
                    {
                        game.setPos(row, col); //Sets the private game row and col variables
                        game.GameBoard = game.getTurn(); //Sets the gameBoard to an X or O value
                        obj.Content = game.GameBoard; //Sets the UI board with the corresponding X/O

                        if (hasWon = game.isWinningMove())//If someone has won
                        {
                            highlightWinningMove();//Highlight what the winning move was
                            status = game.changeStatus();//Update the status of the game to show who won
                            lblStatus.Content = status;//Update the label to show who won
                            hasGameStarted = false;//Game is over
                            updateStats();//Update stats counter
                        }
                        else if (isTie = game.isTie())//If no one has won yet, check if there is a tie
                        {
                            status = game.changeStatus();//Update the status if there is a tie
                            lblStatus.Content = status;//Show that it's a tie
                            hasGameStarted = false;//Game's over
                            updateStats();//Update stats
                        }
                        else//If no one has won, and there wasn't a tie, just update the status
                        {
                            status = game.changeStatus();
                            lblStatus.Content = status;
                        }
                    }

                }
                //Two different classes, an AI class (which is derived from the base class) and the base class.
                //If we are playing against the AI, we need to call the AI class
                else if (aiGame)
                {
                    string status = "Player 1's Turn"; //Default status
                    Label obj = (Label)sender; //We will want to know what label was clicked on
                    string[]? pos = obj.Tag.ToString().Split(","); //Used to identify position. Each tag has a row/col in the form of r,c
                    int row, col;
                    row = Int32.Parse(pos[0]); //Gets the row position from the Tag
                    col = Int32.Parse(pos[1]); //Gets the col position from the Tag

                    if (vsAi.isEmpty(row, col)) //If the spot on the board is empty, its a valid move
                    {
                        vsAi.setPos(row, col); //Sets the private game row and col variables
                        vsAi.GameBoard = vsAi.getTurn(); //Sets the gameBoard to an X or O value
                        obj.Content = vsAi.GameBoard; //Sets the UI board with the corresponding X/O

                        if (hasWon = vsAi.isWinningMove())//If someone has won
                        {
                            highlightWinningMove();//Highlight what the winning move was
                            status = vsAi.changeStatus();//Update the status of the game to show who won
                            lblStatus.Content = status;//Update the label to show who won
                            hasGameStarted = false;//Game is over
                            updateStats();//Update stats counter
                        }
                        else if (isTie = vsAi.isTie())//If no one has won yet, check if there is a tie
                        {
                            status = vsAi.changeStatus();//Update the status if there is a tie
                            lblStatus.Content = status;//Show that it's a tie
                            hasGameStarted = false;//Game's over
                            updateStats();//Update stats
                        }
                        else//If no one has won, and there wasn't a tie, just update the status
                        {
                            status = vsAi.changeStatus();
                            lblStatus.Content = status;
                        }
                    }
                    //If Player 1 (aka the human) hasn't won, and there isn't a tie, and it's the AI's turn, the AI makes its move
                    if (!hasWon && !isTie && status == "Player 2's Turn")
                    {
                        vsAi.getMove();
                        if (hasWon = vsAi.isWinningMove())//If someone has won
                        {
                            highlightWinningMove();//Highlight what the winning move was
                            status = vsAi.changeStatus();//Update the status of the game to show who won
                            lblStatus.Content = status;//Update the label to show who won
                            hasGameStarted = false;//Game is over
                            updateStats();//Update stats counter
                        }
                        else if (isTie = vsAi.isTie())//If no one has won yet, check if there is a tie
                        {
                            status = vsAi.changeStatus();//Update the status if there is a tie
                            lblStatus.Content = status;//Show that it's a tie
                            hasGameStarted = false;//Game's over
                            updateStats();//Update stats
                        }
                        else//If no one has won, and there wasn't a tie, just update the status
                        {
                            status = vsAi.changeStatus();
                            lblStatus.Content = status;
                        }
                        resetLabels();
                        loadBoard();
                    }

                }

            }
        }

        /// <summary>
        /// Resets the background colors of the labels so that we aren't showing the winning move of last game
        /// </summary>
        private void resetColors()
        {
            lblTopLeft.Background = new SolidColorBrush(Colors.Transparent);
            lblTopRight.Background = new SolidColorBrush(Colors.Transparent);
            lblTopMid.Background = new SolidColorBrush(Colors.Transparent);

            lblMidLeft.Background = new SolidColorBrush(Colors.Transparent);
            lblMidRight.Background = new SolidColorBrush(Colors.Transparent);
            lblMid.Background = new SolidColorBrush(Colors.Transparent);

            lblBotLeft.Background = new SolidColorBrush(Colors.Transparent);
            lblBotRight.Background = new SolidColorBrush(Colors.Transparent);
            lblBotMid.Background = new SolidColorBrush(Colors.Transparent);

        }
        /// <summary>
        /// Clears the UI (not the actual game board) for reloading
        /// </summary>
        private void resetLabels()
        {
            lblTopLeft.Content = "";
            lblTopMid.Content = "";
            lblTopRight.Content = "";

            lblMidLeft.Content = "";
            lblMid.Content = "";
            lblMidRight.Content = "";

            lblBotLeft.Content = "";
            lblBotMid.Content = "";
            lblBotRight.Content = "";

        }

        /// <summary>
        /// Used to reload the board when the AI makes a move
        /// Doesn't need to check for human vs AI since this is only called when playing against the AI
        /// Reason being that the AI doesn't call the playerMoveClick function
        /// </summary>
        private void loadBoard()
        {
            vsAi.setPos(0, 0);
            lblTopLeft.Content = vsAi.GameBoard;

            vsAi.setPos(0, 1);
            lblTopMid.Content = vsAi.GameBoard;

            vsAi.setPos(0, 2);
            lblTopRight.Content = vsAi.GameBoard;

            vsAi.setPos(1, 0);
            lblMidLeft.Content = vsAi.GameBoard;

            vsAi.setPos(1, 1);
            lblMid.Content = vsAi.GameBoard;

            vsAi.setPos(1, 2);
            lblMidRight.Content = vsAi.GameBoard;

            vsAi.setPos(2, 0);
            lblBotLeft.Content = vsAi.GameBoard;

            vsAi.setPos(2, 1);
            lblBotMid.Content = vsAi.GameBoard;

            vsAi.setPos(2, 2);
            lblBotRight.Content = vsAi.GameBoard;
        }
        /// <summary>
        /// Updates the stats of the game to show total wins and ties
        /// If its an AI game, update the AI class, else update the normal class
        /// </summary>
        private void updateStats()
        {
            if (humanGame)
            {
                int p1Wins, p2Wins, ties;
                p1Wins = game.getPlayer1Wins(); //Gets Player 1's win count
                p2Wins = game.getPlayer2Wins();//Gets player 2's win count
                ties = game.getTies();//Gets the tie count

                //Updating the labels
                countP1Wins.Content = p1Wins.ToString();
                countP2Wins.Content = p2Wins.ToString();
                countTies.Content = ties.ToString();
            }
            else if (aiGame)
            {
                int p1Wins, p2Wins, ties;
                p1Wins = vsAi.getPlayer1Wins(); //Gets Player 1's win count
                p2Wins = vsAi.getPlayer2Wins();//Gets player 2's win count
                ties = vsAi.getTies();//Gets the tie count

                //Updating the labels
                countP1Wins.Content = p1Wins.ToString();
                countP2Wins.Content = p2Wins.ToString();
                countTies.Content = ties.ToString();
            }
        }


        /// <summary>
        /// Takes the returned boolean value from the TicTacToe class, and highlights the appropriate row/col/diagonal
        /// Checks if its a human game or AI game to call the correct class function
        /// </summary>
        private void highlightWinningMove()
        {
            if (humanGame)
            {
                game.getWinningMove();
                if (game.row1)//Top row
                {
                    lblTopLeft.Background = new SolidColorBrush(Colors.Yellow);
                    lblTopMid.Background = new SolidColorBrush(Colors.Yellow);
                    lblTopRight.Background = new SolidColorBrush(Colors.Yellow);
                }
                else if (game.row2)//Middle Row
                {
                    lblMidLeft.Background = new SolidColorBrush(Colors.Yellow);
                    lblMid.Background = new SolidColorBrush(Colors.Yellow);
                    lblMidRight.Background = new SolidColorBrush(Colors.Yellow);
                }
                else if (game.row3)//Bottom Row
                {
                    lblBotLeft.Background = new SolidColorBrush(Colors.Yellow);
                    lblBotMid.Background = new SolidColorBrush(Colors.Yellow);
                    lblBotRight.Background = new SolidColorBrush(Colors.Yellow);
                }
                else if (game.col1)//Left Column
                {
                    lblMidLeft.Background = new SolidColorBrush(Colors.Yellow);
                    lblTopLeft.Background = new SolidColorBrush(Colors.Yellow);
                    lblBotLeft.Background = new SolidColorBrush(Colors.Yellow);
                }
                else if (game.col2)//Middle Column
                {
                    lblTopMid.Background = new SolidColorBrush(Colors.Yellow);
                    lblMid.Background = new SolidColorBrush(Colors.Yellow);
                    lblBotMid.Background = new SolidColorBrush(Colors.Yellow);
                }
                else if (game.col3)//Right column
                {
                    lblTopRight.Background = new SolidColorBrush(Colors.Yellow);
                    lblBotRight.Background = new SolidColorBrush(Colors.Yellow);
                    lblMidRight.Background = new SolidColorBrush(Colors.Yellow);
                }
                else if (game.diag1)//Top left to bottom right diagonal
                {
                    lblTopLeft.Background = new SolidColorBrush(Colors.Yellow);
                    lblMid.Background = new SolidColorBrush(Colors.Yellow);
                    lblBotRight.Background = new SolidColorBrush(Colors.Yellow);
                }
                else if (game.diag2)//Bottom left to top right diagonal
                {
                    lblTopRight.Background = new SolidColorBrush(Colors.Yellow);
                    lblMid.Background = new SolidColorBrush(Colors.Yellow);
                    lblBotLeft.Background = new SolidColorBrush(Colors.Yellow);
                }
            }
            else if (aiGame)
            {
                vsAi.getWinningMove();
                if (vsAi.row1)//Top row
                {
                    lblTopLeft.Background = new SolidColorBrush(Colors.Yellow);
                    lblTopMid.Background = new SolidColorBrush(Colors.Yellow);
                    lblTopRight.Background = new SolidColorBrush(Colors.Yellow);
                }
                else if (vsAi.row2)//Middle Row
                {
                    lblMidLeft.Background = new SolidColorBrush(Colors.Yellow);
                    lblMid.Background = new SolidColorBrush(Colors.Yellow);
                    lblMidRight.Background = new SolidColorBrush(Colors.Yellow);
                }
                else if (vsAi.row3)//Bottom Row
                {
                    lblBotLeft.Background = new SolidColorBrush(Colors.Yellow);
                    lblBotMid.Background = new SolidColorBrush(Colors.Yellow);
                    lblBotRight.Background = new SolidColorBrush(Colors.Yellow);
                }
                else if (vsAi.col1)//Left Column
                {
                    lblMidLeft.Background = new SolidColorBrush(Colors.Yellow);
                    lblTopLeft.Background = new SolidColorBrush(Colors.Yellow);
                    lblBotLeft.Background = new SolidColorBrush(Colors.Yellow);
                }
                else if (vsAi.col2)//Middle Column
                {
                    lblTopMid.Background = new SolidColorBrush(Colors.Yellow);
                    lblMid.Background = new SolidColorBrush(Colors.Yellow);
                    lblBotMid.Background = new SolidColorBrush(Colors.Yellow);
                }
                else if (vsAi.col3)//Right column
                {
                    lblTopRight.Background = new SolidColorBrush(Colors.Yellow);
                    lblBotRight.Background = new SolidColorBrush(Colors.Yellow);
                    lblMidRight.Background = new SolidColorBrush(Colors.Yellow);
                }
                else if (vsAi.diag1)//Top left to bottom right diagonal
                {
                    lblTopLeft.Background = new SolidColorBrush(Colors.Yellow);
                    lblMid.Background = new SolidColorBrush(Colors.Yellow);
                    lblBotRight.Background = new SolidColorBrush(Colors.Yellow);
                }
                else if (vsAi.diag2)//Bottom left to top right diagonal
                {
                    lblTopRight.Background = new SolidColorBrush(Colors.Yellow);
                    lblMid.Background = new SolidColorBrush(Colors.Yellow);
                    lblBotLeft.Background = new SolidColorBrush(Colors.Yellow);
                }
            }
        }
        
    }
}
