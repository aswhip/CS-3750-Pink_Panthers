﻿using System;
using System.Collections.Generic;
using System.Net;

// -------------------------------------------------------------------------
// if using .NET Framework
// https://docs.microsoft.com/en-us/dotnet/api/system.web.script.serialization.javascriptserializer?view=netframework-4.8
// This requires including the reference to System.Web.Extensions in your project

// -------------------------------------------------------------------------
// if using .Net Core
// https://docs.microsoft.com/en-us/dotnet/api/system.text.json?view=net-5.0
using System.Text.Json;
// -------------------------------------------------------------------------

namespace ConsoleTests
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            string? again;
            do
            {
                string api = "VDQGXUW9L8SCQKNN";
                string? stockCode;

                Console.WriteLine("Enter the Stock Code you would like to search for: ");
                stockCode = Console.ReadLine();
                string QUERY_URL = $"https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol={stockCode}&apikey={api}";
                Uri queryUri = new Uri(QUERY_URL);

                using (WebClient client = new WebClient())
                {
                    string data = client.DownloadString(queryUri);
                    Console.WriteLine(data);
                }
                Console.WriteLine("Would you like to test another code? (Y/y for yes, anything else for No): ");
                again = Console.ReadLine();
            } while (again!.ToLower().Equals("y"));

            Console.WriteLine("Goodbye");
        }

    }
}